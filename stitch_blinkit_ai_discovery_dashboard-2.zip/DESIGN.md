---
name: Quick Commerce Pulse
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#3c4a3c'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#6c7b6b'
  outline-variant: '#bbcbb9'
  surface-tint: '#006e2f'
  primary: '#006e2f'
  on-primary: '#ffffff'
  primary-container: '#0ccf60'
  on-primary-container: '#005221'
  inverse-primary: '#36e371'
  secondary: '#006e16'
  on-secondary: '#ffffff'
  secondary-container: '#8ffb87'
  on-secondary-container: '#007518'
  tertiary: '#974730'
  on-tertiary: '#ffffff'
  tertiary-container: '#ff997d'
  on-tertiary-container: '#772f1b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#66ff8e'
  primary-fixed-dim: '#36e371'
  on-primary-fixed: '#002109'
  on-primary-fixed-variant: '#005322'
  secondary-fixed: '#8ffb87'
  secondary-fixed-dim: '#74dd6e'
  on-secondary-fixed: '#002203'
  on-secondary-fixed-variant: '#00530e'
  tertiary-fixed: '#ffdbd1'
  tertiary-fixed-dim: '#ffb5a1'
  on-tertiary-fixed: '#3b0900'
  on-tertiary-fixed-variant: '#79301b'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
  express-yellow: '#FFD700'
  text-main: '#1F1F1F'
  text-muted: '#666666'
  border-subtle: '#EEEEEE'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  margin-mobile: 16px
  margin-desktop: 24px
  gutter: 12px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style

The design system is engineered for a "minutes-to-doorstep" service model, prioritizing speed, freshness, and accessibility. The brand personality is hyper-reliable yet friendly, evoking the feeling of a helpful neighborhood assistant powered by high-tech logistics.

The aesthetic follows a **Modern Corporate** approach with **Soft Minimalist** influences. It utilizes generous whitespace to reduce cognitive load during rapid browsing. Visual interest is generated through high-contrast brand colors against clean surfaces rather than complex textures. The interface feels "breathable" and organized, ensuring that product imagery remains the hero while the UI provides a sturdy, trustworthy framework.

## Colors

The palette is anchored by "Blinkit Green," a vibrant, high-energy hue that signifies growth and freshness. This is supported by a deep forest green used primarily for high-contrast typography and critical action states to ensure AAA accessibility.

- **Primary (#0CCF60):** Used for primary call-to-actions, success states, and brand-heavy elements.
- **Secondary (#0C831F):** Reserved for text contrast against light backgrounds and "Add" button states.
- **Express Yellow (#FFD700):** A tactical accent color used exclusively for "Instant" or "Express" badges and limited-time offers.
- **Neutral/Background:** A crisp white (#FFFFFF) is the primary surface color, with a very light gray (#F8F8F8) used to differentiate sections or tile backgrounds.

## Typography

This design system uses **Plus Jakarta Sans** across all levels to maintain a contemporary, welcoming vibe. The type scale is optimized for "glanceability," which is essential for users shopping on the move.

- **Headlines:** Use Bold (700) or ExtraBold (800) weights with slightly tighter letter-spacing to create a strong visual anchor for category titles.
- **Body:** Medium (500) is preferred for product names to ensure they stand out against prices and descriptions.
- **Labels:** Used for unit measurements (e.g., "500g") and delivery estimates. These should often use the Forest Green secondary color for maximum legibility at small sizes.

## Layout & Spacing

The layout utilizes a **Fluid Grid** model with high-density information mapping. On mobile devices, a 2-column or 3-column product grid is standard, while desktop expands to a 6-column configuration.

- **Margins:** A strict 16px margin on mobile ensures content doesn't feel cramped while maximizing horizontal screen real estate for product tiles.
- **Rhythm:** An 8px-based spacing system governs vertical stacks. Use 4px for tight relationships (e.g., price vs. unit) and 16px-24px for logical section breaks.
- **Horizontal Scrollers:** Used extensively for categories and "Recommended" sections to encourage discovery without increasing page length.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **High-Contrast Borders** rather than aggressive shadows.

- **Surfaces:** The base layer is white. Secondary containers (like search bars or category backgrounds) use the neutral light-gray.
- **Borders:** Instead of heavy shadows, use a 1px solid border (#EEEEEE) for card elements. This keeps the UI feeling "flat" and modern.
- **Shadows:** Reserved only for floating elements like the "View Cart" bar or active modals. These shadows should be extremely diffused (20px-30px blur) with very low opacity (5-8%) to avoid a muddy appearance.

## Shapes

The design system employs a **Rounded** shape language to reinforce the "friendly grocery" feel. 

- **Cards:** Product tiles and promotional banners use a 16px radius.
- **Buttons:** Primary action buttons use a 12px-16px radius, depending on size, to maintain a soft but functional appearance.
- **Inputs:** Search bars and quantity selectors use a semi-pill shape (minimum 24px radius) to differentiate them from static cards.

## Components

- **Primary Buttons:** High-contrast green (#0CCF60) with white text. For "Add" buttons, use a white background with a secondary green (#0C831F) border and text to indicate an available action.
- **Product Cards:** Must include a fixed-ratio image container at the top, followed by delivery time (highlighted in Green/Bold), product name, and a bottom-aligned price/action row.
- **Chips:** Small, rounded badges used for "Bestseller" or "Deal" tags. Use light tinted backgrounds of the brand colors with dark text.
- **Search Bar:** A prominent, persistent element at the top of the interface. It should feature a soft gray background and a subtle inner shadow to feel "recessed" into the header.
- **Quantity Selectors:** Once a product is added, the button should transform into a stepper ( - 1 + ) with a Forest Green background to provide clear tactile feedback for quantity adjustments.
- **Cart Bottom-Sheet:** A persistent floating bar that appears when items are in the cart. It should use a primary green background with a "slide-up" animation to indicate urgency and success.